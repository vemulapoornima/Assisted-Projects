
public class Flute extends Instruments{

	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}
