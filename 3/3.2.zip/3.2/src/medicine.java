

public class medicine {


	
	
		public void displayLabel(){
			System.out.println("Company : Cipla");
			System.out.println("Address : Hyderabad");
			
		}
		
}
	class Tablet extends medicine{
		 
	public void displayLabel(){
		System.out.println("store in a cool dry place");
		}
	}
	class Syrup extends medicine{public void displayLabel()
	{
		System.out.println("Consumption as directed by the physician");
		}
	}
	class Ointment extends medicine{
		public void displayLabel(){
			System.out.println("for external use only");
		}
}


